/* $Id: whole.pl,v 1.5 2003/06/05 10:00:35 diaz Exp $ */

:-	include(read_file).
:-	include(bip_list).
:-	include(syn_sugar).
:-	include(internal).
:-	include(code_gen).
:-	include(reg_alloc).
:-	include(inst_codif).
:-	include(first_arg).
:-	include(indexing).
:-	include(wam_emit).
:-	include(pl2wam).
